from email.mime.text import MIMEText
import socket
from django.shortcuts import render
from decimal import Decimal
from django.conf import settings
import random
# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import User, Container, Book
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .forms import UserLoginForm, UserRegisterForm
from django.contrib.auth.decorators import login_required
from decimal import Decimal
import stripe
import smtplib, ssl
from django.template.loader import render_to_string
from datetime import datetime
from .visual import *

stripe.api_key = 'sk_test_51IqFoDSJfP377fWh0l368RrYVrmoawFBHfsssUskpx3tDoN3EBHG4cnhiTnxLcbCMv4oglXyO4hoIbsH6RYSV8Mz00vdDU2Yf3'

def home(request):
    if request.user.is_authenticated:
        return render(request, 'myapp/home.html')
    else:
        return render(request, 'myapp/signin.html')


@login_required(login_url='signin')
def payment(request):
    context = {}
    if request.method == 'POST':
        id_r = request.POST.get('con_id')
        # seats_r = int(request.POST.get('no_seats'))
        try:
            book = Book.objects.get(id=id_r)
            Book.objects.filter(id=id_r).update(payment='PAID')
            cost = book.price * book.nos
            from_r = book.source
            to = book.dest
            date = book.date
            cname = book.container_name
            email_r = request.user.email
            name_r = request.user.username

            context['key'] = 'pk_test_51IqFoDSJfP377fWhyweO0OrHrt0WLsQErCeD4y4jb62VsKRdNBeFoeEXYm2finNj7RDnrnX9sFEfazXJYv9lBYvM00j1SVu9gs'
            context['cost'] = cost*100
            context['costa'] = cost
            context['from_r'] = from_r
            context['to'] = to
            context['date'] = date
            context['cname'] = cname

            mc = {}
            mc['cost'] = cost * 100
            mc['costa'] = cost
            mc['from_r'] = from_r
            mc['to'] = to
            mc['date'] = date
            mc['cname'] = cname
            mc['name'] = name_r

            template = render_to_string('myapp/paymail.html', mc)
            port = 465  # For SSL
            smtp_server = "smtp.gmail.com"
            sender_email = "dev.ternlogistics@gmail.com"  # Enter your address
            receiver_email = email_r  # Enter receiver address
            password = 'Gmail@2001'
            msg = MIMEText(template)

            msg['Subject'] = 'TernLogistics Payment Successful'
            conteqt = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=conteqt) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, msg.as_string())

            return render(request, 'myapp/payment.html', context)
        except Book.DoesNotExist:
            context["error"] = "Sorry You have not booked that container"
    else:
        return render(request, 'myapp/findbus.html')



@login_required(login_url='signin')
def charge(request):
    context = {}
    if request.method == 'POST':
        amt = request.POST.get('amt')
        float_str = float(amt)
        amount = int(float_str)
        charge = stripe.Charge.create(
            amount=amount,
            currency='inr',
            description='money',
            source=request.POST['stripeToken']
        )
        rn = random.randint(1000000, 9999999)
        context['sucess']= "Payment Successfully done"
        context['rn'] = rn
        return render(request, 'myapp/charge.html', context)

@login_required(login_url='signin')
def findbus(request):
    context = {}
    if request.method == 'POST':
        source_r = request.POST.get('source')
        dest_r = request.POST.get('destination')
        date_r = request.POST.get('date')
        bus_list = Container.objects.filter(source=source_r, dest=dest_r, date=date_r)
        if bus_list:
            return render(request, 'myapp/list.html', locals())
        else:
            context["error"] = "Sorry no Containers availiable at this Moment. Try later!"
            return render(request, 'myapp/findbus.html', context)
    else:
        return render(request, 'myapp/findbus.html')


@login_required(login_url='signin')
def bookings(request):
    context = {}
    if request.method == 'POST':
        id_r = request.POST.get('bus_id')
        seats_r = int(request.POST.get('no_seats'))
        item_r = request.POST.get('item')
        bus = Container.objects.get(id=id_r)
        if bus:
            if bus.rem > int(seats_r):
                name_r = bus.container_name
                cost = int(seats_r) * bus.price
                source_r = bus.source
                dest_r = bus.dest
                nos_r = Decimal(bus.nos)
                price_r = bus.price
                date_r = bus.date
                time_r = bus.time
                username_r = request.user.username
                email_r = request.user.email
                userid_r = request.user.id
                rem_r = bus.rem - seats_r
                Container.objects.filter(id=id_r).update(rem=rem_r)
                book = Book.objects.create(name=username_r, email=email_r, userid=userid_r, container_name=name_r,
                                           source=source_r, busid=id_r,
                                           dest=dest_r, price=price_r, nos=seats_r, date=date_r, time=time_r,
                                           status='BOOKED', item=item_r, amount=cost)
                maildet ={}
                maildet['name'] = username_r
                maildet['cname'] = name_r
                maildet['from'] = source_r
                maildet['to'] = dest_r
                maildet['amount'] = cost
                maildet['date'] = date_r
                maildet['time'] = time_r
                maildet['bid'] = book.id

                template = render_to_string('myapp/mail.html', maildet)
                port = 465  # For SSL
                smtp_server = "smtp.gmail.com"
                sender_email = "dev.ternlogistics@gmail.com"  # Enter your address
                receiver_email = email_r  # Enter receiver address
                password = 'Gmail@2001'
                # message = template
                # message['Subject'] = "TernLogistics Container Booked"
                msg = MIMEText(template)

                msg['Subject'] = 'TernLogistics Container BOOKED'
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                    server.login(sender_email, password)
                    server.sendmail(sender_email, receiver_email, msg.as_string())

                print('------------book id-----------', book.id)
                # book.save()
                return render(request, 'myapp/bookings.html', locals())
            else:
                context["error"] = "Sorry out of space! Select lower size."
                return render(request, 'myapp/findbus.html', context)

    else:
        return render(request, 'myapp/findbus.html')


@login_required(login_url='signin')
def tracking(request):
    context = {}
    if request.method == 'POST':
        id_r = request.POST.get('track_id')
        try:
            book = Book.objects.get(id=id_r)
            container = Container.objects.get(id=book.busid)

            nature = book.nature
            insp = container.inspection
            start = container.started
            deliv = container.delivered
            check = book.check
            cname = book.container_name

            context['cname'] = cname
            context['check'] = check
            context['nature'] = nature
            context['insp'] = insp
            context['start'] = start
            context['deliv'] = deliv
            return render(request, 'myapp/tracking.html', context)
        except Book.DoesNotExist:
            context["error"] = "Sorry You have not booked that container"
            return render(request, 'myapp/error.html', context)
    return render(request, seebookings)


@login_required(login_url='signin')
def cancellings(request):
    context = {}
    if request.method == 'POST':
        id_r = request.POST.get('bus_id')
        #seats_r = int(request.POST.get('no_seats'))

        try:
            book = Book.objects.get(id=id_r)
            email_r = request.user.email
            name_r = request.user.username
            bus = Container.objects.get(id=book.busid)
            rem_r = bus.rem + book.nos
            Container.objects.filter(id=book.busid).update(rem=rem_r)
            #nos_r = book.nos - seats_r
            Book.objects.filter(id=id_r).update(status='CANCELLED')
            Book.objects.filter(id=id_r).update(payment='REFUNDED')
            Book.objects.filter(id=id_r).update(nos=0)
            maildet = {}
            maildet['name'] = name_r
            template = render_to_string('myapp/cancelmail.html', maildet)
            port = 465  # For SSL
            smtp_server = "smtp.gmail.com"
            sender_email = "dev.ternlogistics@gmail.com"  # Enter your address
            receiver_email = email_r  # Enter receiver address
            password = 'Gmail@2001'
            # message = template
            # message['Subject'] = "TernLogistics Container Booked"
            msg = MIMEText(template)

            msg['Subject'] = 'TernLogistics Container CANCELED'
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, msg.as_string())

            return redirect(seebookings)
        except Book.DoesNotExist:
            context["error"] = "Sorry You have not booked that container"
            return render(request, 'myapp/error.html', context)
    else:
       return render(request, 'myapp/findbus.html')




@login_required(login_url='signin')
def seebookings(request, new={}):
    context = {}
    id_r = request.user.id
    book_list = Book.objects.filter(userid=id_r)
    if book_list:
        return render(request, 'myapp/booklist.html', locals())
    else:
        context["error"] = "Sorry no Containers booked"
        return render(request, 'myapp/findbus.html', context)


@login_required(login_url='signin')
def dashboard(request):
    context ={}

    data = Container.objects.all()
    x = [x.container_name for x in data]
    y = [y.price for y in data]
    chart1 = get_plot1(x, y)
    context['chart1'] = chart1

    data3 = Container.objects.all()
    x = [x.container_name for x in data3]
    y = [y.nos for y in data3]
    chart3 = get_plot3(x, y)
    context['chart3'] = chart3

    id_r = request.user.id
    data2 = Book.objects.filter(userid=id_r)
    x = [x.item for x in data2]
    y = [y.nos for y in data2]
    chart2 = get_plot2(x, y)
    context['chart2'] = chart2

    x = [x.item for x in data2]
    y = [y.amount for y in data2]
    chart4 = get_plot4(x, y)
    context['chart4'] = chart4

    x = [x.id for x in data2]
    y = [y.amount for y in data2]
    chart5 = get_plot5(x, y)
    context['chart5'] = chart5

    x = [x.id for x in data2]
    y = [y.date for y in data2]
    chart6 = get_plot6(x, y)
    context['chart6'] = chart6


    return render(request, 'myapp/dashboard.html', context)


def signup(request):
    context = {}
    if request.method == 'POST':
        first_name_r = request.POST.get('first_name')
        last_name_r = request.POST.get('last_name')
        name_r = request.POST.get('name')
        email_r = request.POST.get('email')
        password_r = request.POST.get('password')
        user = User.objects.create_user(name_r, email_r, password_r)
        user.is_active = True
        user.first_name = first_name_r
        user.last_name = last_name_r
        user.save()
        context['name'] = first_name_r
        if user:
            login(request, user)


            email_r = request.user.email
            template = render_to_string('myapp/accountcreation.html', context)  # sending message
            port = 465  # For SSL
            smtp_server = "smtp.gmail.com"
            sender_email = "dev.ternlogistics@gmail.com"  # Enter your address
            receiver_email = email_r  # Enter receiver address
            password = 'Gmail@2001' # password of sendermail
            msg = MIMEText(template)

            msg['Subject'] = 'TernLogistics Account Created Successfully'
            conteqt = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=conteqt) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, msg.as_string())

            return render(request, 'myapp/thank.html')
        else:
            context["error"] = "Provide valid credentials"
            return render(request, 'myapp/signup.html', context)
    else:
        return render(request, 'myapp/signup.html', context)


def signin(request):
    context = {}
    if request.method == 'POST':
        name_r = request.POST.get('name')
        password_r = request.POST.get('password')
        user = authenticate(request, username=name_r, password=password_r)

        if user:
            login(request, user)
            # username = request.session['username']
            context["user"] = name_r
            context["id"] = request.user.id
            email_r = request.user.email
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            context['ip'] = ip
            now = datetime.now()

            context['time'] = now.strftime("%H:%M:%S")

            template = render_to_string('myapp/loginsucess.html', context)
            port = 465  # For SSL
            smtp_server = "smtp.gmail.com"
            sender_email = "dev.ternlogistics@gmail.com"  # Enter your address
            receiver_email = email_r  # Enter receiver address
            password = 'Gmail@2001'
            msg = MIMEText(template)

            msg['Subject'] = 'TernLogistics Logged in Successfully'
            conteqt = ssl.create_default_context()
            with smtplib.SMTP_SSL(smtp_server, port, context=conteqt) as server:
                server.login(sender_email, password)
                server.sendmail(sender_email, receiver_email, msg.as_string())


            return render(request, 'myapp/home.html', context)
            # return HttpResponseRedirect('success')
        else:
            context["error"] = "Login Failed! Provide valid credentials"
            return render(request, 'myapp/signin.html', context)
    else:
        context["error2"] = "You are not logged in"
        return render(request, 'myapp/signin.html', context)


def signout(request):
    context = {}
    logout(request)
    context['error2'] = "You have been logged out"
    return render(request, 'myapp/signin.html', context)


def success(request):
    context = {}
    context['user'] = request.user
    return render(request, 'myapp/success.html', context)



