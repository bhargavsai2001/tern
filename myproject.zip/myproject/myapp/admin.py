from django.contrib import admin
from .models import Container, User, Book


class BookAdmin(admin.ModelAdmin):
    list_editable = ('payment', 'nature', 'status', 'check')
    list_display = ('name', 'item', 'source', 'dest', 'container_name', 'nos', 'status', 'payment', 'nature', 'check')
    list_filter = ('date','item', 'container_name')


class ContainerAdmin(admin.ModelAdmin):
    list_editable = ('inspection', 'started', 'delivered')
    list_display = ('container_name', 'source', 'dest', 'nos', 'rem', 'date', 'time', 'inspection', 'started', 'delivered')
    list_filter = ('date', )
# Register your models here.

admin.site.site_header = "TernLogistics Admin Panel"


admin.site.register(Container, ContainerAdmin)
admin.site.register(User)
admin.site.register(Book, BookAdmin)


