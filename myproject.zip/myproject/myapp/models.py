# Create your models here.
from django.db import models


# Create your models here.

class Container(models.Model):
    CITIES = (
        ('Ahmedabad', 'Ahmedabad'),
        ('Bangalore', 'Bangalore'),
        ('Bhopal', 'Bhopal'),
        ('Chennai', 'Chennai'),
        ('Delhi', 'Delhi'),
        ('Guntur', 'Guntur'),
        ('Hyderabad', 'Hyderabad'),
        ('Jaipur', 'Jaipur'),
        ('Kolkata', 'Kolkata'),
        ('Lucknow', 'Lucknow'),
        ('Mumbai', 'Mumbai'),
        ('Patna', 'Patna'),
        ('Pune', 'Pune'),
        ('Vijayawada', 'Vijayawada'),
        ('Vizag', 'Vizag'),
    )

    container_name = models.CharField(max_length=30)
    source = models.CharField(choices=CITIES, default='Guntur', max_length=30)
    dest = models.CharField(choices=CITIES, default='Hyderabad', max_length=30)
    nos = models.DecimalField(decimal_places=0, max_digits=8)
    rem = models.DecimalField(decimal_places=0, max_digits=8)
    price = models.DecimalField(decimal_places=2, max_digits=10)
    date = models.DateField()
    time = models.TimeField()
    inspection = models.BooleanField('Inspection', default=False)
    started = models.BooleanField('Started', default=False)
    delivered = models.BooleanField('Delivered', default=False)

    def __str__(self):
        return self.container_name


class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    email = models.EmailField()
    name = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30, default='anonymous')
    last_name = models.CharField(max_length=30, default='anonymous')
    password = models.CharField(max_length=30)

    def __str__(self):
        return self.email + ' - ' + self.name


class Book(models.Model):
    BOOKED = 'BOOKED'
    CANCELLED = 'CANCELLED'
    PAID = 'PAID'
    UNPAID = 'UNPAID'
    REFUNDED = 'REFUNDED'
    RECEIVED = 'RECEIVED'
    NOT_RECEIVED = 'NOT RECEIVED'

    ITEMS = (
        ('PETROLEUM PRODUCTS', 'PETROLEUM PRODUCTS'),
        ('PEARLS , PRECIOUS AND SEMIPRECIOUS STONES', 'PEARLS , PRECIOUS AND SEMIPRECIOUS STONES'),
        ('MEDICINES & BIOLOGICALS', 'MEDICINES & BIOLOGICALS'),
        ('GOLD & OTHER PRECIOUS METAL JEWELLERY', 'GOLD & OTHER PRECIOUS METAL JEWELLERY'),
        ('IRON & STEEL', 'IRON & STEEL'),
        ('ORGANIC CHEMICALS', 'ORGANIC CHEMICALS'),
        ('TEXTILES', 'TEXTILES'),
        ('PLASTIC', 'PLASTIC'),
        ('MOTOR VEHICLES', 'MOTOR VEHICLES'),
        ('AGRICULTURE & DAIRY', 'DAIRY'),
        ('ELECTRIC MACHINERY & EQUIPMENT', 'ELECTRIC MACHINERY & EQUIPMENT'),
        ('PRODUCTS OF IRON & STEEL', 'PRODUCTS OF IRON & STEEL'),
        ('PRODUCTS OF PLASTIC & SILICON', 'PRODUCTS OF PLASTIC & SILICON'),
    )

    CITIES = (
        ('Ahmedabad', 'Ahmedabad'),
        ('Bangalore', 'Bangalore'),
        ('Bhopal', 'Bhopal'),
        ('Chennai', 'Chennai'),
        ('Delhi', 'Delhi'),
        ('Guntur', 'Guntur'),
        ('Hyderabad', 'Hyderabad'),
        ('Jaipur', 'Jaipur'),
        ('Kolkata', 'Kolkata'),
        ('Lucknow', 'Lucknow'),
        ('Mumbai', 'Mumbai'),
        ('Patna', 'Patna'),
        ('Pune', 'Pune'),
        ('Vijayawada', 'Vijayawada'),
        ('Vizag', 'Vizag'),
    )

    RECEIVE_STATUS = ((RECEIVED, 'RECEIVED'), (NOT_RECEIVED, 'NOT RECEIVED'))
    PAYMENT_STATUSES = ((PAID, 'PAID'), (UNPAID, 'UNPAID'), (REFUNDED, 'REFUNDED'))
    TICKET_STATUSES = ((BOOKED, 'BOOKED'),
                       (CANCELLED, 'CANCELLED'),)
    email = models.EmailField()
    name = models.CharField(max_length=30)
    userid = models.DecimalField(decimal_places=0, max_digits=2)
    busid = models.DecimalField(decimal_places=0, max_digits=2)
    container_name = models.CharField(max_length=30)
    source = models.CharField(choices=CITIES, default='Guntur', max_length=30)
    dest = models.CharField(choices=CITIES, default='Hyderabad', max_length=30)
    nos = models.DecimalField(decimal_places=0, max_digits=10)
    price = models.DecimalField(decimal_places=2, max_digits=6)
    amount = models.DecimalField(decimal_places=2, default=0, max_digits=10)
    date = models.DateField()
    time = models.TimeField()
    status = models.CharField(choices=TICKET_STATUSES, default=BOOKED, max_length=10)
    payment = models.CharField(choices=PAYMENT_STATUSES, default=UNPAID, max_length=10)
    nature = models.CharField(choices=RECEIVE_STATUS, default=NOT_RECEIVED, max_length=15)
    item = models.CharField(choices=ITEMS, default='PLASTIC', max_length=80)
    check = models.BooleanField('Checked', default=True)


    def __str__(self):
        return self.name