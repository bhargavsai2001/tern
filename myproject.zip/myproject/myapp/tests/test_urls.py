from django.urls import reverse, resolve


class TestUrls:

    def test_bookings_url(self):
        path = reverse('bookings')
        assert resolve(path).view_name == 'bookings'

    def test_findbus_url(self):
        path = reverse('findbus')
        assert resolve(path).view_name == 'findbus'

    def test_cancellings_url(self):
        path = reverse('cancellings')
        assert resolve(path).view_name == 'cancellings'

    def test_seebookings_url(self):
        path = reverse('seebookings')
        assert resolve(path).view_name == 'seebookings'

    def test_signup_url(self):
        path = reverse('signup')
        assert resolve(path).view_name == 'signup'

    def test_tracking_url(self):
        path = reverse('tracking')
        assert resolve(path).view_name == 'tracking'

    def test_signin_url(self):
        path = reverse('signin')
        assert resolve(path).view_name == 'signin'

    def test_success_url(self):
        path = reverse('success')
        assert resolve(path).view_name == 'success'

    def test_signout_url(self):
        path = reverse('signout')
        assert resolve(path).view_name == 'signout'

    def test_payment_url(self):
        path = reverse('payment')
        assert resolve(path).view_name == 'payment'

    def test_charge_url(self):
        path = reverse('charge')
        assert resolve(path).view_name == 'charge'

    def test_dashboard_url(self):
        path = reverse('dashboard')
        assert resolve(path).view_name == 'dashboard'
