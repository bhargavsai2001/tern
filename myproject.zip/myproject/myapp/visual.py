import matplotlib.pyplot as plt
import base64
from io import BytesIO
import matplotlib as mpl


def get_graph():
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    graph = base64.b64encode(image_png)
    graph = graph.decode('utf-8')
    buffer.close()
    return graph


def get_plot1(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(6,4))
    plt.title('CONTAINERS PRICE DATA')
    plt.bar(x,y, color='lightseagreen', width= 0.5)
    plt.xticks(rotation=90)
    plt.xlabel('Container Name')
    plt.ylabel('Price')
    plt.tight_layout()
    graph = get_graph()
    return graph

def get_plot3(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(6,4))
    plt.title('CONTAINERS SIZE DATA')
    plt.bar(x,y, color='lightseagreen', width= 0.5)
    plt.xticks(rotation=90)
    plt.xlabel('Container Name')
    plt.ylabel('SIZE')
    plt.tight_layout()
    graph = get_graph()
    return graph



def get_plot2(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(12,5))
    plt.title('Booking Analysis')
    plt.bar(x,y, color='#3678aa', width= 0.4)
    plt.xticks(rotation=45)
    plt.xlabel('Item')
    plt.ylabel('Space')
    plt.tight_layout()
    graph = get_graph()
    return graph

def get_plot4(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(12,5))
    plt.title('Spend Analysis')
    plt.scatter(x,y, color='#3678aa')
    plt.xticks(rotation=45)
    plt.xlabel('Item')
    plt.ylabel('Amount')
    plt.tight_layout()
    graph = get_graph()
    return graph


def get_plot5(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(6,3))
    plt.title('Spend Analysis')
    plt.plot(x,y, color='#3678aa')
    plt.xticks(rotation=0)
    plt.xlabel('ID')
    plt.ylabel('Amount')
    plt.tight_layout()
    graph = get_graph()
    return graph


def get_plot6(x,y):
    mpl.style.use('seaborn-dark-palette')
    plt.switch_backend('AGG')
    plt.figure(figsize=(6,3))
    plt.title('BOOKINGS')
    plt.bar(x,y, color='#3678aa', width=0.2)
    plt.xticks(rotation=0)
    plt.xlabel('ID')
    plt.ylabel('Date')
    plt.tight_layout()
    graph = get_graph()
    return graph




